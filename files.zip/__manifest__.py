{
    "name": "Obras",
    "author": "Tu nombre",
    "version": "1.0",
    "depends": ["base", "sale", "hr", "product"],
    "data": [
        "views/obras_views.xml",
        "views/registro_diario_views.xml"
    ],
    "installable": True,
}